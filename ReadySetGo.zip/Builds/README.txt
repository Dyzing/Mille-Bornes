**************************************************************************
********************	READY SET GO ! SPECIAL OFFER	******************
**************************************************************************

Bonjour et merci cher joueur d'avoir téléchargé "Ready Set Go ! Special Offer".

Ce jeu est un remaster du jeu de société très connu du Mille Bornes.
Les règles sont un peu différentes.

Je vous invite à regarder les règles du Mille Bornes sur le web si vous ne les connaissez pas encore.

La différence est qu'il ne faut pas avoir de carte "Roulez" afin de pouvoir commencer la partie ou après un malus pour reprendre la route.

Les cartes "bottes" (increvable, citerne d'essence, vehicule prioritaire, as du volant) sont des cartes qui clean le(s) malus correspondant(s) et ajoute un bouclier contre ce(s) malus correspondant(s).
Les boucliers se consomment après l'affectation du malus correspondant sur le joueur.

IMPORTANT : Il faut attendre que tous les joueurs soient sur l'écran "TAP TO START" dans le serveur avant de lancer la partie (de tap). Sinon il faudra retourner dans le lobby pour refaire la manipulation.
Ceci sera corrigé dans une mise à jour à venir.

Profitez et roulez vers la liberté !

Lien du répo Git : https://github.com/Dyzing/Mille-Bornes

******************************************************************
********************	Guillaume TREM		******************
********************	CEG Entertainment	******************	
******************************************************************
